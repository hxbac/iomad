    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    .column {
            width: 100%;
      		padding: 10px 10px 10px 10px;
        }
        
        .imgstyle {
            width: 80%;
        }
        
        .textstyle {
            text-align: center;
        }
      	
      .newbackground{
			margin-left: calc(50% - 50vw);
    		margin-right: calc(50% - 50vw);
            /*background-color: #E9E9E9;*/
            background-image: linear-gradient(to right, #fc5c7d, #6a82fb);
            background-size: cover;
          }
      
      .imgborder{
        border: 2px solid #E9E9E9
      }
      
      
      @media (min-width: 660px) {
            .columns {
                display: flex;
                flex-direction: row;
                flex-wrap: nowrap;
                width: 90%;
            }
            .imgstyle {
                width: 90%;
                margin-top: 10px;
            }
          .textstyle {
            text-align: justify;
       		}
          .newbackground{
			margin-left: calc(50% - 50vw);
    		margin-right: calc(50% - 50vw);
            /*background-color: #E9E9E9;*/
            background-image: linear-gradient(to right, #fc5c7d, #6a82fb);
            background-size: cover;
            height: 80%;
          }
        }
    }
  
    </style>
    <div style="clear:both"></div>
    <div align="center">
        <div class="columns">
            <div class="column">
                <h3>Học tập chủ động</h3>
                <p><img src="pix/news/news_pix01.png" class="imgstyle" /></p>
                <p class="textstyle">Hệ thống cung cấp các chương trình học tập trực tuyến cho phép học tập chủ động, mọi lúc và mọi nơi.</p>
            </div>
            <div class="column">
                <h3>Nội dung phong phú</h3>
                <p><img src="pix/news/news_pix02.png" class="imgstyle" /></p>
                <p class="textstyle">Hệ thống cung cấp nhiều bài học có nội dung hấp dẫn, đa dạng, thu hút người học.</p>
            </div>
            <div class="column">
                <h3>Tính tương tác cao </h3>
                <p><img src="pix/news/news_pix03.png" class="imgstyle" /></p>
                <p class="textstyle">Hệ thống bao gồm các công cụ hỗ trợ học tập phong phú, dễ dàng tương tác giữa người học và người dạy.</p>
            </div>
            <div class="column">
                <h3>Hỗ trợ trực tuyến </h3>
                <p><img src="pix/news/news_pix04.png" class="imgstyle" /></p>
                <p class="textstyle">Đội ngũ chuyên nghiệp sẽ hỗ trợ người sử dụng hệ thống một cách nhanh chóng và dễ dàng nhất.</p>
            </div>
        </div>
    </div>
	<br>
	<div class="newbackground">
      <div align="center">
        <div class="columns">
          <div class="column">
      	 	<p><img src="pix/news/8.jpg" class="imgstyle imgborder"  /></p>
          </div>
          <div class="column">
      	 	<p><img src="pix/news/2.jpg" class="imgstyle imgborder" /></p>
          </div>
          <div class="column">
      	 	<p><img src="pix/news/3.jpg" class="imgstyle imgborder" /></p>
          </div>
          <div class="column">
      	 	<p><img src="pix/news/4.jpg" class="imgstyle imgborder" /></p>
          </div>
          <div class="column">
      	 	<p><img src="pix/news/5.jpg" class="imgstyle imgborder" /></p>
          </div>
          <div class="column">
      	 	<p><img src="pix/news/7.jpg" class="imgstyle imgborder" /></p>
          </div>
       </div>
      </div>
	</div>
	<br>
	<br>
