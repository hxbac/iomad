Message My Teacher block for Moodle

This block allows configuration of roles to be considered "Teachers" of a course.  The block will
then display a list of these teachers for the current course in the block, with a link to message
each one.

To install, place all files in /blocks/messageteacher and visit /admin/index.php in your browser

This block was written by Mike Worth <mike@mike-worth.com> and Mark Johnson <mark@barrenfrozenwasteland.com>. 
It is Copyright Mark Johnson and Richard Taunton Sixth Form College. 
It is currently maintained by Mark Johnson.

Development of Version 2.3 was sponsored by Connecting Waters Charter School (http://connectingwaters.org/)

Development of user image and group support sponsored by Proud Photography (http://www.ProudPhotography.com) – Online Photography School.

Released Under the GNU General Public Licence http://www.gnu.org/copyleft/gpl.html
