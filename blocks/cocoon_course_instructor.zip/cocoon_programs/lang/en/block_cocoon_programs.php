<?php

$string['configtitle'] = 'Block title';
$string['cocoon_programs:addinstance'] = 'Add a new Custom slider block';
$string['cocoon_programs:myaddinstance'] = 'Add a new Custom slider block to Dashboard';
$string['leaveblanktohide'] = 'leave blank to hide the title';
$string['newcustomsliderblock'] = '(new Custom slider block)';
$string['pluginname'] = '[Cocoon] Programs';

$string['slides_number'] = 'Number of slides';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_image'] = 'Image';
$string['config_slide_title'] = 'Title';
$string['config_slide_subtitle'] = 'Subtitle';
$string['config_file_slide'] = 'Image';
