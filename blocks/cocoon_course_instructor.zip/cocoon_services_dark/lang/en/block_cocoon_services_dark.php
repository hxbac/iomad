<?php

$string['configtitle'] = 'Block title';
$string['cocoon_services_dark:addinstance'] = 'Add a new [Cocoon] Services Dark block';
$string['cocoon_services_dark:myaddinstance'] = 'Add a new [Cocoon] Services Dark block to Dashboard';
$string['pluginname'] = '[Cocoon] Services Dark';
