<?php

$string['configtitle'] = 'Block title';
$string['cocoon_price_tables:addinstance'] = 'Add a new [Cocoon] Price Tables block';
$string['cocoon_price_tables:myaddinstance'] = 'Add a new [Cocoon] Price Tables block to Dashboard';
$string['pluginname'] = '[Cocoon] Price Tables';
