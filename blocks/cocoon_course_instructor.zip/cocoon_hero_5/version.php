<?php

defined('MOODLE_INTERNAL') || die;

$plugin->version = 2020081513.10;
$plugin->requires  = 2018051700;
$plugin->component = 'block_cocoon_hero_5';
