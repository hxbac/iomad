<?php
$plugin->version = 2020081513.10;
$plugin->requires = 2017111300;
$plugin->component    = 'block_cocoon_course_rating';
