<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2020081817.37;
$plugin->requires  = 2017051504;
$plugin->component = 'block_cocoon_pills';
