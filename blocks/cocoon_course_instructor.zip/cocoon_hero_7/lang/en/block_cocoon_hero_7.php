<?php
$string['pluginname'] = '[Cocoon] Hero 7';
$string['cocoon_hero_7'] = '[Cocoon] Hero 7';
$string['cocoon_hero_7:addinstance'] = 'Add a new [Cocoon] Hero 7 block';
$string['cocoon_hero_7:myaddinstance'] = 'Add a new [Cocoon] Hero 7 block to the My Moodle page';
