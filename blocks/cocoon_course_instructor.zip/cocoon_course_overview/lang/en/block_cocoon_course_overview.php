<?php
$string['pluginname'] = '[Cocoon] Course Overview';
$string['cocoon_course_overview'] = '[Cocoon] Course Overview';
$string['cocoon_course_overview:addinstance'] = 'Add a new Course Overview block';
$string['cocoon_course_overview:myaddinstance'] = 'Add a new Course Overview block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_description'] = 'Description';
